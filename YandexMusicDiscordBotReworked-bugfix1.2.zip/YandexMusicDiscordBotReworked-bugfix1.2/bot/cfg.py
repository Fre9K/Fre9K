import os

token = os.environ["discordBotToken"]
YMToken = os.environ["YMTOKEN"]