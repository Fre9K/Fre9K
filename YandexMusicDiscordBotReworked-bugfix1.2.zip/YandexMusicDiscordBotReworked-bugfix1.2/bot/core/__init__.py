from .bot import PersistentViewBot

Bot = PersistentViewBot()
